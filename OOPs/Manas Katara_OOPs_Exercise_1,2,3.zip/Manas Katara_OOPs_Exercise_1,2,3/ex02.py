class Book:
    def __init__(self, title, author):
        self.title = title
        self.author = author

    def get_details(self):
        return f"{self.title} by {self.author}"

class Library:
    def __init__(self, name):
        self.name = name
        self.books = []

    def add_book(self, book):
        self.books.append(book)

    def display_books(self):
        print(f"Books in {self.name} library:")
        for book in self.books:
            print(book.get_details())


book1 = Book("The Alchemist", "Paulo Coelho")
book2 = Book("To Kill a Mockingbird", "Harper Lee")
book3 = Book("Pride and Prejudice", "Jane Austen")

library = Library("Main Library")
library.add_book(book1)
library.add_book(book2)
library.add_book(book3)

# display the books in the library
library.display_books()
