# ex-03
class Employee:
    def __init__(self, name, age, salary):
        self.name = name
        self.age = age
        self.salary = salary

    def work(self):
        print(f"{self.name} is working.")

class Programmer(Employee):
    def __init__(self, name, age, salary, programming_language):
        super().__init__(name, age, salary)
        self.programming_language = programming_language

    def code(self):
        print(f"{self.name} is coding in {self.programming_language}.")

class Manager(Employee):
    def __init__(self, name, age, salary, team_size):
        super().__init__(name, age, salary)
        self.team_size = team_size

    def manage(self):
        print(f"{self.name} is managing a team of {self.team_size} employees.")

employee = Employee("John", 30, 50000)

class Shape:
    def __init__(self, color):
        self.color = color

    def compute_parameter(self):
        pass

    def compute_area(self):
        pass

    def draw_shape(self):
        pass

import math

class Circle(Shape):
    def __init__(self, color, radius):
        super().__init__(color)
        self.radius = radius

    def compute_parameter(self):
        return 2 * math.pi * self.radius

    def compute_area(self):
        return math.pi * (self.radius ** 2)

    def draw_shape(self):
        print(f"Drawing {self.color} circle with radius {self.radius}.")

class Rectangle(Shape):
    def __init__(self, color, length, width):
        super().__init__(color)
        self.length = length
        self.width = width

    def compute_parameter(self):
        return 2 * (self.length + self.width)

    def compute_area(self):
        return self.length * self.width

    def draw_shape(self):
        print(f"Drawing {self.color} rectangle with length {self.length} and width {self.width}.")

class Trapezium(Shape):
    def __init__(self, color, base1, base2, height, side1, side2):
        super().__init__(color)
        self.base1 = base1
        self.base2 = base2
        self.height = height
        self.side1 = side1
        self.side2 = side2

    def compute_parameter(self):
        return self.base1 + self.base2 + self.side1 + self.side2

    def compute_area(self):
        return 0.5 * (self.base1 + self.base2) * self.height

    def draw_shape(self):
        print(f"Drawing {self.color} trapezium with bases {self.base1} and {self.base2}, height {self.height}, and sides {self.side1} and {self.side2}.")
